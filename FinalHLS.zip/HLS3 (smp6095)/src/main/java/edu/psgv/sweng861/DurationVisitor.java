package edu.psgv.sweng861;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.psgv.sweng861.PlaylistError.ErrorSeverity;
import edu.psgv.sweng861.URLConnectionReader.PlaylistType;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Check for duration errors - media files cannot exceed target duration
public class DurationVisitor implements IVisitor 
{
	//Class variable
	private static final Logger logger = LogManager.getLogger(DurationVisitor.class.getName());
	
	//Constructor
	public DurationVisitor() 
	{
		logger.info(">>DurationVisitor constructor");		
	}
	
	//Visit Playlist to check duration (polymorphic)
	public void visit(Playlist playlist)
	{
		logger.info(">>visit(Playlist)");
		ArrayList<String> contents = playlist.getContents();
		//Duration check applicable to MediaPlaylist only
		if (playlist instanceof MediaPlaylist)
		{
			logger.info("Playlist identified as MediaPlaylist");
			//Locate target duration in media playlist file
			for (int i = 0; i < contents.size(); i++)
			{
				logger.debug("Iteration: {}", i);
				if(contents.get(i).startsWith(PlaylistConstants.TARGETDURATION))
				{
					logger.debug("Row starts with {}: {}", PlaylistConstants.TARGETDURATION, contents.get(i));
					String temp = contents.get(i).substring(22); //Remove #EXT-X-TARGETDURATION:
					logger.debug("Target duration found: {}", temp);
					playlist.setTargetDuration(Float.parseFloat(temp));
					logger.debug("Target duration property set: {}", playlist.getTargetDuration());
				}
			}
			//Collect durations into an ArrayList<Float>
			ArrayList<Float> durations = new ArrayList<Float>();
			for (int i = 0; i < contents.size(); i++)
			{
				logger.debug("Iteration: {}", i);
				if(contents.get(i).startsWith(PlaylistConstants.MEDIASEGMENTDURATION))
				{
					logger.debug("Row starts with {}: {}", PlaylistConstants.MEDIASEGMENTDURATION, contents.get(i));
					String temp = contents.get(i).substring(8); //Remove #EXTINF:
					logger.debug("Remove {} tag: {}", PlaylistConstants.MEDIASEGMENTDURATION, temp);
					int j = temp.indexOf(',');
					if (j > 0) //If ',' found - will return -1 if not
					{
						temp = temp.substring(0, j); //Remove title after duration
						logger.debug("Remove content after duration: {}", temp);
					}
					float segmentDuration = Float.parseFloat(temp);
					durations.add(segmentDuration);
					logger.debug("Final seqment duration {} added to durations collection for review", segmentDuration);
				}
			}
			//Compare durations to targetDuration for validation
			int errorCount = 0;
			for (int i = 0; i < durations.size(); i++)
			{
				logger.debug("Iteration: {} / Segment duration: {} / Target duration: {}", i, durations.get(i), playlist.getTargetDuration());
				if(durations.get(i) > playlist.getTargetDuration()) 
				{
					//Generate a new error and add to playlist's collection of errors
					PlaylistError newError = new PlaylistError(ErrorSeverity.MAJOR, i, contents.get(i), "Duration error - segment duration of " + durations.get(i) + " exceeds playlist target duration of " + playlist.getTargetDuration());
					playlist.addPlaylistError(newError);
					logger.debug("New target duration error added to playlist's error collection");
					//Count errors
					errorCount++;
					logger.debug("Target duration error count: {}", errorCount);
				}
			}
			if (errorCount == 0)
			{
				logger.info("PASSED duration validation, all segment durations less than/equal to playlist target duration");
				playlist.setValidDuration(true);
			}
			else
			{
				logger.info("FAILED duration validation - {} new duration error(s) added to playlist's error collection", errorCount);
				playlist.setValidDuration(false);
			}
		}
		else
		{
			logger.info("No duration check for non-MediaPlaylist");
			playlist.setValidDuration(true); //Default true when N/A
		}
	}
}