package edu.psgv.sweng861;

import java.util.ArrayList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.psgv.sweng861.PlaylistError.ErrorSeverity;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Concrete implementation of IVisitor - checks for illegal whitespace
class WhitespaceVisitor implements IVisitor
{
	//Class variables
	private final Logger logger = LogManager.getLogger(WhitespaceVisitor.class.getName());
	
	//Constructor
	public WhitespaceVisitor() 
	{
		logger.info(">>WhitespaceVisitor constructor");
	}
	
	//Visit and validate no whitespace on blank rows of list - Playlist (polymorphic)
	@Override
	public void visit(Playlist playlist)
	{
		logger.info(">>visit(Playlist)");
		ArrayList<String> contents = new ArrayList<String>();
		contents = playlist.getContents();
		int errorCount = 0;
		for (int i = 0; i < contents.size(); i++)
		{
			logger.debug("Iteration: {}  Line data: {}", i, contents.get(i));
			if (contents.get(i).startsWith(" "))
			{
				//Generate a new error and add to playlist's collection of errors
				PlaylistError newError = new PlaylistError(ErrorSeverity.MINOR, i, contents.get(i), "Illegal whitespace found at beginning of row");
				playlist.addPlaylistError(newError);
				logger.debug("New whitespace error added to playlist's error collection");
				//Count errors
				errorCount++;
				logger.debug("Whitespace error count: {}", errorCount);
			}
		}
		if (errorCount == 0)
		{
			logger.info("PASSED whitespace validation");
			playlist.setValidNoWhitespace(true);
		}
		else
		{
			logger.info("FAILED whitespace validation - {} new whitespace error(s) added to playlist's error collection", errorCount);
			playlist.setValidNoWhitespace(false);
		}
	}
}
