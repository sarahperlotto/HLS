package edu.psgv.sweng861;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Interface for concrete visitors (logger excluded for interface)
interface IVisitor 
{
	void visit(Playlist playlist);
}
