package edu.psgv.sweng861;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.psgv.sweng861.URLConnectionReader.PlaylistType;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Concrete implementation of Playlist
public class MasterPlaylist extends Playlist
{
	//Class variables
	private static final Logger logger = LogManager.getLogger(MasterPlaylist.class.getName());
	ArrayList<Playlist> variantPlaylists = new ArrayList<Playlist>(); 
	boolean validVariants;
	
	//Constructor
	public MasterPlaylist(ArrayList<String> playlistContents, String playlistUrl)
	{
		super(playlistContents, playlistUrl);
		logger.info(">>MasterPlaylist constructor");
		truncatedUrl = truncateUrl(); //Ready to concat with variant media file paths
		logger.info(">>MasterPlaylist constructor");
		//Create new variant media playlists
		ArrayList<String> variantUrls = new ArrayList<String>(); 
		variantUrls = parsePlaylist(contents); 
		variantPlaylists = buildPlaylists(variantUrls);
	}
	
	@Override
	//Accept visitor by passing self-argument to overloaded visitor interface constructor
	public void accept(IVisitor visitor)
	{
		logger.info(">>accept()");
		visitor.visit(this);
	}
	
	//Access to variantPlaylists (get)
	public ArrayList<Playlist> getVariantPlaylists()
	{
		return variantPlaylists;
	}	
	
	//Parse contents into individual playlist URIs
	ArrayList<String> parsePlaylist(ArrayList<String> contents)
	{
		logger.info(">>parseMasterPlaylist()");
		ArrayList<String> urls = new ArrayList<String>();
		for (int i = 0; i < contents.size(); i++)
		{
			logger.debug("Iteration: {}", i);
			if (contents.get(i).startsWith(PlaylistConstants.VARIANTSTREAM))
			{
				logger.debug("Row starts with {}: {}", PlaylistConstants.VARIANTSTREAM, contents.get(i));
				String temp = contents.get(i + 1); //Get URI on next row
				logger.debug("URI on next row: {}", temp);
				temp = truncatedUrl.concat(temp); //Build full URI
				logger.debug("Full URI: {}", temp);
				urls.add(temp);
				logger.debug("URI {} added to collection", temp);
			}
		}
		return urls;
	}
	
	//Build variant playlists for parsed URLs 
	ArrayList<Playlist> buildPlaylists(ArrayList<String> batchUrls)
	{
		logger.info(">>buildPlaylists()");
		ArrayList<Playlist> variantPlaylists = new ArrayList<Playlist>(); 
		for (int i = 0; i < batchUrls.size(); i++)
		{
			logger.debug("Iteration: {}", i);
			String urlArgument = batchUrls.get(i);
			System.out.println("URL submitted: " + urlArgument);
			boolean valid = URLConnectionReader.validateInput(urlArgument);
			logger.debug("URL valid?: {}", valid);
			//Get and print contents for valid URLs
			if (valid)
			{
				ArrayList<String> tempPlaylistData = URLConnectionReader.getUrlContents(urlArgument);
				//URLConnectionReader.printUrlContents(tempPlaylistData);
				URLConnectionReader.PlaylistType type = URLConnectionReader.determinePlaylistType(tempPlaylistData);
				logger.debug("Playlist type: {}", type);
				//Create new playlist
				if (type == PlaylistType.MEDIA) //Only media playlists should be listed in master playlist
				{
					Playlist playlist = new MediaPlaylist(tempPlaylistData, urlArgument);
					variantPlaylists.add(playlist);
					logger.info("New media playlist object created and added to MasterPlaylist");
					URLConnectionReader.addVisitors(playlist);
					logger.info("Visitors created and added to new MediaPlaylist");
					//Print validation report as subheader of master
					//playlist.printValidationReport();
				}
				else //Invalid playlist
				{
					System.out.println("Invalid playlist - cannot proceed");
					logger.info("No new playlist object created");
				}
			}
			else
			{
				System.out.println("Invalid URL");
			}
		}
		return variantPlaylists;
	}
	
	@Override
	//Print results of visitors - override from abstract parent
	void printValidationReport()
	{
		//Finalize and print master validation report
		logger.info(">>printValidationReport()");
		validationDetails();
		validVariants = variantErrors();
		if (validVariants)
		{
			validPlaylist = errorCheck(); //Check for other errors
		}
		else
		{
			validPlaylist = false;
			System.out.println("\nInvalid variant playlist identified - see playlist validation report(s) for details");
		}
		System.out.println("\n        Valid playlist: " + validPlaylist);
		System.out.println("");
		//Master playlist to print variant playlists' validation reports
		for (int j = 0; j < variantPlaylists.size(); j++)
		{
			logger.debug("Printing variant playlist validation report, interation: {}", j);
			variantPlaylists.get(j).printValidationReport();
		}
	}
	
	//Check for errors in variant playlists
	boolean variantErrors()
	{
		for (int i = 0; i < variantPlaylists.size(); i++)
		{
			boolean check = variantPlaylists.get(i).errorCheck();
			if (!check) 
			{
				return false; //Any error found - fail
			}
		}
		return true; //No error found - pass
	}
}
