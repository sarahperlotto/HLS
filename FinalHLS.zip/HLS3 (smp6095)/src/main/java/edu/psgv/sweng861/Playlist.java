package edu.psgv.sweng861;

import java.util.ArrayList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.psgv.sweng861.URLConnectionReader.PlaylistType;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Generalization of specific playlist media files
abstract class Playlist 
{
	//Class variables
	private static final Logger logger = LogManager.getLogger(Playlist.class.getName());
	String url;
	String truncatedUrl;
	ArrayList<String> contents;
	ArrayList<PlaylistError> playlistErrors;
	float targetDuration = 0;
	//Potential future enhancements - hold flags in ArrayList
	boolean validFirstRecord;
	boolean validDuration;
	boolean validNoWhitespace;
	boolean validTagSequence;
	boolean validTagList;
	boolean validPlaylist;
	
	//Constructor
	public Playlist(ArrayList<String> playlistContents, String playlistUrl)
	{
		logger.info(">>Playlist constructor");
		contents = playlistContents;
		url = playlistUrl;
		truncatedUrl = truncateUrl();
		playlistErrors = new ArrayList<>();
	}
	
	//Accept visitor by passing self-argument to overloaded visitor interface constructor
	public void accept(IVisitor visitor)
	{
		logger.info(">>accept()");
		visitor.visit(this);
	}
	
	//Print results of visitors - to override in implementations
	abstract void printValidationReport();
	
	//Common validation actions to call from child implementations of printValidationReport();
	void validationDetails()
	{
		logger.info(">>validationDetails()");
		System.out.println("\n***/// PLAYLIST VALIDATION REPORT ///***");
		System.out.println("          Playlist URL: " + url);
		System.out.println("         Playlist type: " + this.getClass());
		//Loop through playlist details to print details
		System.out.println("\n          ***/// ERROR DETAIL ///***");
		if (playlistErrors.isEmpty())
		{
			System.out.println("            No errors identified!");
		}
		else
		{
			for (int i = 0; i < playlistErrors.size(); i++)
			{
				playlistErrors.get(i).printErrorDetails();
			}
		}
	}
	
	//Check playlist error flags
	boolean errorCheck()
	{
		logger.trace(">>errorCheck()");
		logger.debug("Valid first record?: {}", validFirstRecord);
		logger.debug("Valid duration?: {}", validDuration);
		logger.debug("Valid no whitespace?: {}", validNoWhitespace);
		logger.debug("Valid tag sequence?: {}", validTagSequence);
		logger.debug("Valid tag list? (doesn't drive validity): {}", validTagList);
		if (validFirstRecord && validDuration && validNoWhitespace && validTagSequence) 
		//validTagList purposefully not included, invalid tag shouldn't cause failure, should just be ignored
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	//Truncate playlist URL to prepare for locating variants or segments
	String truncateUrl()
	{
		logger.info(">>truncateUrl()");
		int i = url.lastIndexOf('/');
		String truncated = url.substring(0, i + 1);
		logger.debug("Original MasterPlaylist URL: {}", url);
		logger.debug("Truncated MasterPlaylist URL: {}", truncated);
		return truncated;
	}
	
	//Access to truncatedUrl (get)
	public String getTruncatedUrl()
	{
		return truncatedUrl;
	}

	//Access to contents (get)
	public ArrayList<String> getContents()
	{
		logger.info(">>getContents()");
		return contents;
	}
	
	//Access to URL (get)
	public String getUrl()
	{
		logger.info(">>getUrl()");
		return url;
	}
	
	//Access to targetDuration (set)
	public void setTargetDuration(float duration)
	{
		targetDuration = duration;
	}
	
	//Access to targetDuration (get)
	public float getTargetDuration()
	{
		return targetDuration;
	}
	
	//Access to valid flag (set)
	public void setValidFirstRecord(boolean value)
	{
		logger.info(">>setValidFirstRecord()");
		validFirstRecord = value;
		logger.info("ValidFirstRecord: {}", validFirstRecord);
	}
	
	//Access to duration flag (set)
	public void setValidDuration(boolean value)
	{
		logger.info(">>setValidDuration()");
		validDuration = value;
		logger.info("ValidDuration: {}", validDuration);
	}
	
	//Access to whitespace flag (set)
	public void setValidNoWhitespace(boolean value)
	{
		logger.info(">>setValidNoWhitespace()");
		validNoWhitespace = value;
		logger.info("ValidNoWhitespace: {}", validNoWhitespace);
	}
	
	//Access to whitespace flag (set)
	public void setValidTagSequence(boolean value)
	{
		logger.info(">>setValidTagOrder()");
		validTagSequence = value;
		logger.info("ValidTagOrder: {}", validTagSequence);
	}
	
	//Access to whitespace flag (set)
	public void setValidTagList(boolean value)
	{
		logger.info(">>setValidTagList()");
		validTagList = value;
		logger.info("ValidTagList: {}", validTagSequence);
	}
	
	//Access to errors collection - add new errors
	public void addPlaylistError(PlaylistError newError)
	{
		playlistErrors.add(newError);
	}
}
