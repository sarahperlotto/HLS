package edu.psgv.sweng861;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Concrete implementation of Playlist
class MediaPlaylist extends Playlist
{
	//Class variable
	private static final Logger logger = LogManager.getLogger(MediaPlaylist.class.getName());
	
	//Constructor
	public MediaPlaylist(ArrayList<String> playlistContents, String playlistUrl)
	{
		super(playlistContents, playlistUrl);
		logger.info(">>MediaPlaylist constructor");
	}
	
	@Override
	//Accept visitor by passing self-argument to overloaded visitor interface constructor
	public void accept(IVisitor visitor)
	{
		logger.info(">>accept()");
		visitor.visit(this);
	}
	
	@Override
	//Print results of visitors - override from abstract parent
	void printValidationReport()
	{
		logger.info(">>printValidationReport()");
		validationDetails();
		validPlaylist = errorCheck();
		System.out.println("\n        Valid playlist: " + validPlaylist);
		System.out.println("");
	}
}