package edu.psgv.sweng861;

import java.util.ArrayList;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Holds playlist tag values as final variables for extensibility
public class PlaylistConstants 
{
	//Class variables
	public final static String FIRSTRECORD = "#EXTM3U";
	public final static String TARGETDURATION = "#EXT-X-TARGETDURATION";
	public final static String MEDIASEGMENTDURATION = "#EXTINF";
	public final static String VARIANTSTREAM = "#EXT-X-STREAM-INF";
	public final static String VERSION = "#EXT-X-VERSION";
	public final static String BYTERANGE = "#EXT-X-BYTERANGE";
	public final static String DISCONTINUITY = "#EXT-X-DISCONTINUITY";
	public final static String ENCRYPTION = "#EXT-X-KEY";
	public final static String MAP = "#EXT-X-MAP";
	public final static String PROGRAMDATETIME = "#EXT-X-PROGRAM-DATE-TIME";
	public final static String SEQUENCE = "#EXT-X-MEDIA-SEQUENCE";
	public final static String DISCONTINUITYSEQUENCE = "#EXT-X-DISCONTINUITY-SEQUENCE";
	public final static String ENDLIST = "#EXT-X-ENDLIST";
	public final static String TYPE = "#EXT-X-PLAYLIST-TYPE";
	public final static String IFRAMES = "#EXT-X-I-FRAMES-ONLY";
	public final static String MEDIAALTERNATIVE = "#EXT-X-MEDIA";
	public final static String IFRAMESINF = "#EXT-X-I-FRAME-STREAM-INF";
	public final static String SESSIONDATA = "#EXT-X-SESSION-DATA";
	public final static String SESSIONKEY = "#EXT-X-SESSION-KEY";
	public final static String INDEPENDENTSEGMENTS = "#EXT-X-INDEPENDENT-SEGMENTS";
	public final static String START = "#EXT-X-START";
	public final static String CACHE = "#EXT-X-ALLOW-CACHE"; //Depricated, but valid in past versions and included in test data
}
