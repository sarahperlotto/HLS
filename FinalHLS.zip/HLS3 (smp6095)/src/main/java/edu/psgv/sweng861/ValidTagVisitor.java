package edu.psgv.sweng861;

import java.util.ArrayList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.psgv.sweng861.PlaylistError.ErrorSeverity;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Concrete implementation of IVisitor - checks for invalid tags
public class ValidTagVisitor implements IVisitor
{
	//Class variable
	private static final Logger logger = LogManager.getLogger(TagURIVisitor.class.getName());
	ArrayList<String> validTags = new ArrayList<>();
		
	//Constructor
	public ValidTagVisitor() 
	{
		logger.info(">>ValidTagVisitor constructor");
	}

	//Visit and validate - no invalid tags in playlist (polymorphic implementation)
	@Override
	public void visit(Playlist playlist) 
	{
		logger.info(">>visit(Playlist)");
		createValidTagCollection();
		int errorCount = 0;
		ArrayList<String> contents = playlist.getContents();
		for (int i = 0; i < contents.size(); i++)
		{
			if (contents.get(i).startsWith("#EXT")) //Ignore comments and URIs
			{
				String theTag = parseTag(contents.get(i));
				logger.debug("Tag for review: '{}'", theTag);
				boolean valid = validTags.contains(theTag) || theTag.startsWith(PlaylistConstants.ENDLIST); //Is isolated tag in the collection of valid tags?
				if (!valid)
				{
					PlaylistError newError = new PlaylistError(ErrorSeverity.MINOR, i, contents.get(i), "Unrecognized tag " + theTag + " will be ignored");
					playlist.addPlaylistError(newError);
					logger.debug("New valid tag error added to playlist's error collection");
					errorCount++;
					logger.debug("Invalid tags found: {}", errorCount);
				}
			}
		}
		if (errorCount == 0)
		{
			logger.info("PASSED tag validation, no unrecognized tags identified");
			playlist.setValidTagList(true);
		}
		else //Errors found
		{
			logger.info("DID NOT PASS tag validation, unrecognized tags identified will be ignored");
			playlist.setValidTagList(false);
		}
	}
	
	//Assemble all PlaylistConstants tags into collection for comparison
	void createValidTagCollection()
	{
		logger.info(">>createValidTagCollection()");
		validTags.add(PlaylistConstants.FIRSTRECORD);
		validTags.add(PlaylistConstants.TARGETDURATION);
		validTags.add(PlaylistConstants.MEDIASEGMENTDURATION);
		validTags.add(PlaylistConstants.VARIANTSTREAM);
		validTags.add(PlaylistConstants.VERSION);
		validTags.add(PlaylistConstants.BYTERANGE);
		validTags.add(PlaylistConstants.DISCONTINUITY);
		validTags.add(PlaylistConstants.ENCRYPTION);
		validTags.add(PlaylistConstants.MAP);
		validTags.add(PlaylistConstants.PROGRAMDATETIME);
		validTags.add(PlaylistConstants.SEQUENCE);
		validTags.add(PlaylistConstants.DISCONTINUITYSEQUENCE);
		validTags.add(PlaylistConstants.TYPE);
		validTags.add(PlaylistConstants.IFRAMES);
		validTags.add(PlaylistConstants.MEDIAALTERNATIVE);
		validTags.add(PlaylistConstants.IFRAMESINF);
		validTags.add(PlaylistConstants.SESSIONDATA);
		validTags.add(PlaylistConstants.SESSIONKEY);
		validTags.add(PlaylistConstants.INDEPENDENTSEGMENTS);
		validTags.add(PlaylistConstants.START);
		validTags.add(PlaylistConstants.CACHE);
	}

	//Isolate the tag from a row of data starting with #EXT
	String parseTag(String theRow)
	{
		logger.info(">>parseTag()");
		String theTag = "";
		//Tag can be terminated by new line 
		int i = theRow.indexOf(":");
		logger.debug("Colon found at index {} in String {}", i, theRow);
		if (i == -1)
		{
			theTag = theRow; //No colon - all row contents are tag
		}
		else
		{
			theTag = theRow.substring(0, i); //Colon - only row contents before colon are tag
		}
		theTag.trim();
		logger.debug("Tag parsed as: {}", theTag);
		return theTag;
	}
}
