package edu.psgv.sweng861;

import java.util.ArrayList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.psgv.sweng861.PlaylistError.ErrorSeverity;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Concrete implementation of IVisitor - checks for correct Media/Master URI tags in playlist
class TagURIVisitor implements IVisitor
{
	//Class variable
	private static final Logger logger = LogManager.getLogger(TagURIVisitor.class.getName());
	
	//Constructor
	public TagURIVisitor() 
	{
		logger.info(">>TagURIVisitor constructor");
	}
	
	//Visit and validate no whitespace on blank rows of list - Playlist (polymorphic)
	@Override
	public void visit(Playlist playlist)
	{
		logger.info(">>visit(Playlist)");
		int errorCount = 0;
		ArrayList<String> contents = new ArrayList<>();
		contents = playlist.getContents();
		//This is a bit redundant since #EXTINF and #EXT-X-STREAM-INF tags are used to type and instantiate playlist objects already
		if (playlist instanceof MediaPlaylist)
		{
			logger.debug("Media playlist tag sequence validation");
			for (int i = 0; i < (contents.size() - 1); i++) 
			{
				logger.debug("Interation: {}, Row contents: {}", i, contents.get(i));
				if (contents.get(i).startsWith(PlaylistConstants.VARIANTSTREAM)) //Should not include master tag
				{
					PlaylistError newError = new PlaylistError(ErrorSeverity.MAJOR, i, contents.get(i), "Tag error - master playlist tag " + PlaylistConstants.VARIANTSTREAM + "should not appear in media playlist");
					playlist.addPlaylistError(newError);
					logger.debug("New tag sequence error added to playlist's error collection");
					errorCount++;
					logger.debug("Tag sequence error count: {}", errorCount);
				}
			}
		}
		else if (playlist instanceof MasterPlaylist)
		{
			logger.debug("Master playlist tag sequence validation");
			for (int i = 0; i < (contents.size() - 1); i++) 
			{
				logger.debug("Interation: {}, Row contents: {}", i, contents.get(i));
				if (contents.get(i).startsWith(PlaylistConstants.MEDIASEGMENTDURATION)) //Should not include media tag
				{
					PlaylistError newError = new PlaylistError(ErrorSeverity.MAJOR, i, contents.get(i), "Tag error - media playlist tag " + PlaylistConstants.MEDIASEGMENTDURATION + " should not appear in master playlist");
					playlist.addPlaylistError(newError);
					logger.debug("New tag sequence error added to playlist's error collection");
					errorCount++;
					logger.debug("Tag sequence error count: {}", errorCount);
				}
			}
		}
		else 
		{
			PlaylistError newError = new PlaylistError(ErrorSeverity.FATAL, 0, contents.get(0), "Playlist type could not be resolved for tag sequence validation");
			playlist.addPlaylistError(newError);
			logger.debug("New error added to playlist's error collection");
		}
		if (errorCount == 0)
		{
			logger.info("PASSED tag validation, no invalid tags identified for playlist type");
			playlist.setValidTagSequence(true);
		}
		else //Errors found
		{
			logger.info("FAILED tag validation, invalid tags identified for playlist type");
			playlist.setValidTagSequence(false);
		}
	}
}
