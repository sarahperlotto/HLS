package edu.psgv.sweng861;

import java.io.*;
import java.net.*;
import java.util.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger; 

/*
Based on course materials
HLS v3
Sarah Perlotto
SWENG 861
December 4, 2016
*/

//Main class
public class URLConnectionReader
{
	//Class variables
	private static final Logger logger = LogManager.getLogger(URLConnectionReader.class.getName()); //Logger VM argument: -Dlog4j.configurationFile=./conf/log4j-console-config.xml
	enum PlaylistType {MASTER, MEDIA, INVALID};
	static ArrayList<Playlist> playlistCollection = new ArrayList<Playlist>();
	
	//Main
	public static void main(String[] args)
	{
		logger.info(">>main()");
		System.out.println("Welcome to HLS validator v3.0");
		//Read batch URLs from file when filepath specified in console arguments - use "${project_loc}"/batch.txt to run batch input
		if(args.length > 0)
		{
			runBatchInput(args[0]);
		}
		//Ask for user input if no filepath specified in console arguments
		else
		{
			runUserInput();
		}
		logger.info("<<main()");
	}
	
	//Primary method to retrieve user input
	static void runUserInput()
	{
		Scanner scanner = new Scanner(System.in);
		logger.debug("Scanner open");
		String input = "";
		//Ask for user input, then show results
		while (!(input = getInput(scanner)).equals("0"))
		{
			System.out.println("URL submitted: " + input);
			ArrayList<String> tempPlaylistData = getUrlContents(input);
			//Per professor, instead of printing contents, only print errors in validation report
			//printUrlContents(tempPlaylistData);
			createNewPlaylist(tempPlaylistData, input);
			printPlaylistCollectionValidation();
		}
		scanner.close();
		logger.debug("Scanner closed");
	}

	//Loop to obtain usable user input
	static String getInput(Scanner scanner)
	{
		logger.info(">>getInput()");
		String input;
		boolean validInput = false;
		//Loop for user URL input until valid URL submitted
		do
		{
			input = "";
			System.out.println("Enter a URL or 0 to quit:");
			input = scanForInput(scanner);
			logger.info(">>getInput()");
			validInput = validateInput(input);
			logger.info(">>getInput()");
			logger.debug("Input validated, valid input?: {}", validInput);
		}
		while (!validInput);
		return input;
	}
	
	//Scan for user input
	static String scanForInput(Scanner scanner)
	{
		logger.info(">>scanForInput()");
		String input = "";
		try
		{
			input = scanner.nextLine();
			logger.info("input: {}", input); 
		}
		catch (NoSuchElementException e1)
		{
			System.err.println("Error: no line found " + e1.getMessage());
			logger.error("NoSuchElementException"); //Allow retry
		}
		catch (IllegalStateException e2)
		{
			System.err.println("Error: scanner closed " + e2.getMessage());
			logger.error("IllegalStateException - close");
			input = "0"; 
			return input; //Send back to close
		}
		catch (Exception e3)
		{
			System.err.println("Error: general error " + e3.getMessage());
			logger.error("Exception - close");
			input = "0"; 
			return input; //Send back to close
		}
		return input;
	}
	
	//Validate input to ensure it appears to be a playlist URL
	static boolean validateInput(String input)
	{
		logger.info(">>validateInput()");
		boolean goodInput;
		
		if (input.equals("0"))
		{
			goodInput = true;
			logger.debug("Entry is zero, good value");
		}
		else if (input.isEmpty())
		{
			goodInput = false;
			System.out.println("No entry detected - please try again");
			logger.debug("No entry, retry");
		}
		else if ((!input.startsWith("http://") && !input.startsWith("https://")) || //Input must start with http:// or https:// AND
				(!input.endsWith(".m3u") && !input.endsWith(".m3u8"))) //Input must end with .m3u or .m3u8
		{
			goodInput = false;
			System.out.println("URL must start with http:// or https:// and end with .m3u or .m3u8- please try again");
			logger.debug("Entry doesn't start with http:// or https:// and/or does not end with .m3u or .m3u8, retry"); 
		}
		else
		{
			goodInput = true;
			logger.debug("Entry does not appear to have errors, good value");
		}
		
		logger.debug("Input validated, good input?: {}", goodInput);		
		return goodInput;
	}

	//Retrieve contents at given URL
	static ArrayList<String> getUrlContents(String theUrl)
	{
		logger.info(">>getUrlContents()");
		ArrayList<String> content = new ArrayList<String>();
		String line = "";
		try
		{
			BufferedReader bufferedReader = openURLConnection(theUrl);
			logger.info(">>getUrlContents()");
			while ((line = bufferedReader.readLine()) != null)
			{
				content.add(line);
				logger.debug("New line added: {}", line);
			}
			bufferedReader.close();
			logger.info("Buffered reader closed");
		}
		catch (IOException e)
		{
			System.err.println("Error: input/output error " + e.getMessage());
			logger.error("IOException - return");
			content.clear();
			content.add("bad");
		}
		return content;
	}	
	
	//Open HttpURLConnection
	static BufferedReader openURLConnection(String theUrl) throws IOException
	{
		URL url = new URL(theUrl);
		logger.debug("URL object created");
		HttpURLConnection httpUrlConnection = (HttpURLConnection) url.openConnection();
		logger.debug("HttpURLConnection object created");
		httpUrlConnection.setRequestMethod("GET");
		logger.debug("Sending GET request to HttpURLConnection object");
		int responseCode = httpUrlConnection.getResponseCode();
		logger.debug("HttpURLConnection GET request response code: {}", responseCode);
		if (responseCode >= 200 && responseCode <= 299) //Response code 2xx
		{
			System.out.println("Http GET request sent successfully...");
			logger.debug("Http GET request sent successfully");
		}
		else if (responseCode == 404) //Response code 404
		{
			logger.debug("Http GET request - 404 error identified");
			throw new IOException("Http GET request, 404 error");
		}
		else //Response codes < 200 and > 299 are errors
		{
			logger.debug("Http GET request - error identified");
			throw new IOException("Http GET request, error");
		}
		//Wrap the URLConnection in a BufferedReader
		InputStreamReader inputStreamReader = new InputStreamReader(httpUrlConnection.getInputStream());
		logger.debug("InputStreamReader object created");
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		logger.debug("BufferedReader object created");
		return bufferedReader;
	}
	
	//Create a new playlist based on PlaylistType
	static void createNewPlaylist(ArrayList<String> list, String url)
	{
		logger.info(">>createNewPlaylist()");
		PlaylistType type = determinePlaylistType(list);
		logger.debug("Playlist type: {}", type);
		if (type == PlaylistType.MASTER)
		{
			Playlist playlist = new MasterPlaylist(list, url);
			logger.info("New master playlist object created");
			addVisitors(playlist);
			playlistCollection.add(playlist); //Add to class ArrayList
			logger.debug("Playlist added to playlistCollection ArrayList");
		}
		else if (type == PlaylistType.MEDIA)
		{
			Playlist playlist = new MediaPlaylist(list, url);
			logger.info("New media playlist object created");
			addVisitors(playlist);
			playlistCollection.add(playlist); //Add to class ArrayList
			logger.debug("Playlist added to playlistCollection ArrayList");
		}
		else //Invalid playlist
		{
			System.out.println("Invalid playlist - cannot proceed");
			logger.info("No new playlist object created");
		}
		return;
	}
	
	//Assign visitors to playlist to perform checks
	static void addVisitors(Playlist playlist)
	{
		logger.info(">>addVisitors()");
		//Create visitors
		FirstRecordVisitor firstRecordVisitor = new FirstRecordVisitor();
		WhitespaceVisitor whitespaceVisitor = new WhitespaceVisitor();
		DurationVisitor durationVisitor = new DurationVisitor();
		TagURIVisitor tagURIVisitor = new TagURIVisitor();
		ValidTagVisitor validTagVisitor = new ValidTagVisitor();
		logger.info("New FirstRecordVisitor, WhitespaceVisitor, DurationVisitor, TagURIVisitor, and ValidTagVisitor objects instantiated");
		//Call playlist accept method to assign visitors
		playlist.accept(firstRecordVisitor);
		playlist.accept(whitespaceVisitor);
		playlist.accept(durationVisitor);
		playlist.accept(tagURIVisitor);
		playlist.accept(validTagVisitor);
		logger.info("FirstRecordVisitor, WhitespaceVisitor, DurationVisitor, TagURIVisitor, and ValidTagVisitor  objects accepted by playlist");
	}
	
	//Print validation report for all playlists in collection
	static void printPlaylistCollectionValidation()
	{
		logger.info(">>printPlaylistCollectionValidation()");
		for (int i = 0; i < playlistCollection.size(); i++)
		{
			logger.debug("Iteration: {}", i);
			playlistCollection.get(i).printValidationReport();
		}
	}
	
	//Review playlist tags to determine whether Master or Media type
	static PlaylistType determinePlaylistType(ArrayList<String> playlist)
	{
		logger.info(">>determinePlaylistType()");
		PlaylistType type;
		boolean master = masterTagCheck(playlist);
		logger.info("Playlist contains master playlist tags?: {}", master);
		boolean media = mediaTagCheck1(playlist) && mediaTagCheck2(playlist);
		logger.info("Playlist contains media playlist tags?: {}", media);
		if (master && !media)
		{
			type = PlaylistType.MASTER;
			logger.info("Master playlist - master tags, no media tags");
		}
		else if (!master && media)
		{
			type = PlaylistType.MEDIA;
			logger.info("Media playlist - media tags, no master tags");
		}
		else
		{
			type = PlaylistType.INVALID;
			logger.info("Invalid playlist");
		}
		return type;
	}
	
	//Check for master playlist tags
	static boolean masterTagCheck(ArrayList<String> playlist)
	{
		logger.info(">>masterTagCheck()");
		boolean master = false;
		String masterTag = PlaylistConstants.VARIANTSTREAM;
		for (String current : playlist)
		{
			if (current.startsWith(masterTag))
			{
				logger.debug("Master tag {} found", masterTag);
				return master = true;
			}
		}
		logger.debug("Master tag {} not found", masterTag);
		return master;
	}
	
	//Check for 1st media playlist tag
	static boolean mediaTagCheck1(ArrayList<String> playlist)
	{
		logger.info(">>mediaTagCheck1()");
		boolean media1 = false;
		String mediaTag1 = PlaylistConstants.MEDIASEGMENTDURATION;
		for (String current : playlist)
		{
			if (current.startsWith(mediaTag1))
			{
				logger.debug("First media {} tag found", mediaTag1);
				return media1 = true;
			}
		}
		logger.debug("First media tag {} not found", mediaTag1);
		return media1;
	}	
	
	//Check for 2nd media playlist tag
	static boolean mediaTagCheck2(ArrayList<String> playlist)
	{
		logger.info(">>mediaTagCheck2()");
		boolean media2 = false;
		String mediaTag2 = PlaylistConstants.TARGETDURATION;
		for (String current : playlist)
		{
			if (current.startsWith(mediaTag2))
			{
				logger.debug("First media {} tag found", mediaTag2);
				return media2 = true;
			}
		}
		logger.debug("First media tag {} not found", mediaTag2);
		return media2;
	}		
	
	//Print URL contents
	static void printUrlContents(ArrayList<String> content)
	{
		if(!content.get(0).equals("bad"))
		{
			System.out.println("Playlist contents:\n");
			for (int i = 0; i < content.size(); i++)
			{
				System.out.println(content.get(i));
			}
		}
		else
		{
			System.out.println("URL connection error / URL is not for a valid playlist");
		}
	}

	//Primary method to retrieve batch argument input
	static void runBatchInput(String argument)
	{
		ArrayList<String> batchUrls = readTextFile(argument);
		for (int i = 0; i < batchUrls.size(); i++)
		{
			logger.debug("Iteration: {}", i);
			String urlArgument = batchUrls.get(i);
			System.out.println("URL submitted: " + urlArgument);
			boolean valid = validateInput(urlArgument);
			logger.debug("URL valid?: {}", valid);
			//Get and print contents for valid URLs
			if (valid)
			{
				ArrayList<String> tempPlaylistData = getUrlContents(urlArgument);
				//Per professor, instead of printing contents, only print errors in validation report
				//printUrlContents(tempPlaylistData);
				createNewPlaylist(tempPlaylistData, urlArgument);
			}
			else
			{
				System.out.println("Invalid URL");
			}
		}
		printPlaylistCollectionValidation();
	}
	
	//Load URL batch from file into ArrayList
	static ArrayList<String> readTextFile(String filePath)
	{
		logger.info(">>readTextFile()");
		ArrayList<String> urls = new ArrayList<String>();
		String line = "";
		try
		{
			FileReader fileReader = new FileReader(filePath);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			while((line = bufferedReader.readLine()) != null)
			{
				logger.debug("New line: {}", line);
				urls.add(line);
			}
			bufferedReader.close();
		}
		catch (FileNotFoundException e1)
		{
			System.err.println("Error: file not found error " + e1.getMessage());
			logger.error("FileNotFoundException");
		}
		catch (IOException e2)
		{
			System.err.println("Error: input/output error " + e2.getMessage());
			logger.error("IOException");
		}
		catch (Exception e3)
		{
			System.err.println("Error: general error " + e3.getMessage());
			logger.error("Exception");
		}
		return urls;
	}
}