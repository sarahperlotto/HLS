package edu.psgv.sweng861;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.psgv.sweng861.PlaylistError.ErrorSeverity;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Concrete implementation of IVisitor - checks first record of playlist
class FirstRecordVisitor implements IVisitor
{
	//Class variable
	private static final Logger logger = LogManager.getLogger(FirstRecordVisitor.class.getName());
	
	//Constructor
	public FirstRecordVisitor() 
	{
		logger.info(">>FirstRecordVisitor constructor");
	}
	
	//Visit and validate first record - Playlist (polymorphic)
	@Override
	public void visit(Playlist playlist)
	{
		logger.info(">>visit(Playlist)");
		ArrayList<String> contents = playlist.getContents();
		boolean validFirstRecord = checkFirstRecord(contents);
		if (validFirstRecord)
		{
			logger.info("PASSED first record validation");
			playlist.setValidFirstRecord(true);
		}
		else
		{
			//Generate a new error and add to playlist's collection of errors
			PlaylistError newError = new PlaylistError(ErrorSeverity.FATAL, 0, contents.get(0), "Invalid first record - showing as " + contents.get(0) + " instead of " + PlaylistConstants.FIRSTRECORD);
			playlist.addPlaylistError(newError);
			playlist.setValidFirstRecord(false);
			logger.info("FAILED first record validation - 1 new first record error added to playlist's error collection");
		}
	}

	//Called to validate that the first record starts with #EXTM3U
	boolean checkFirstRecord(ArrayList<String> contents)
	{
		logger.info(">>checkFirstRecord()");
		logger.debug("First record: ", contents.get(0));
		boolean validFirstRecord = contents.get(0).startsWith(PlaylistConstants.FIRSTRECORD);
		return validFirstRecord;
	}
}
