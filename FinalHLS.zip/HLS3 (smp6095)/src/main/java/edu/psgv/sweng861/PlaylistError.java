package edu.psgv.sweng861;

import java.util.ArrayList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Store any errors that occur in Playlists as PlaylistError objects
class PlaylistError 
{
	//Class variables
	private  final Logger logger = LogManager.getLogger(PlaylistError.class.getName());
	enum ErrorSeverity {FATAL, MAJOR, MINOR}
	ErrorSeverity errorSeverity;
	int errorRowNumber;
	String errorRowContents; //Admittedly, this could be retrieved and not a class variable, but this seemed like a more complete implememtation of an error
	String errorDescription;
	Object ErrorSeverity;
	
	//Constructor
	public PlaylistError(ErrorSeverity severity, int row, String contents, String description)
	{
		logger.info(">>PlaylistError constructor");
		errorSeverity = severity;
		errorRowNumber = row;
		errorRowContents = contents;
		errorDescription = description;
	}
	
	//Retrieve errorSeverity
	public ErrorSeverity getSeverity() 
	{
		logger.info(">>getSeverity()");
		return errorSeverity;
	}
	
	//Retrieve errorRowNumber
	public int getRowNumber() 
	{
		logger.info(">>getRowNumber()");
		return errorRowNumber;
	}

	//Retrieve errorRowContents
	public String getRowContents() 
	{
		logger.info(">>getRowContents()");
		return errorRowContents;
	}

	//Retrieve errorDescription
	public String getDescription() 
	{
		logger.info(">>getDescription()");
		return errorDescription;
	}
	
	//Print error data
	public void printErrorDetails()
	{
		logger.info(">>printErrorDetails");
		System.out.println(errorSeverity.toString() + " error on row " + errorRowNumber + ": " + errorDescription);
	}
}
