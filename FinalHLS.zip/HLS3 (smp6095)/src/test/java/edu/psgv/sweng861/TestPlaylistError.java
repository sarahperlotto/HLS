package edu.psgv.sweng861;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.psgv.sweng861.PlaylistError.ErrorSeverity;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

public class TestPlaylistError 
{
	@Before
	public void setUp() throws Exception { }

	@After
	public void tearDown() throws Exception { }
	
	@Test
	//Test for appropriate retrieval of getter - severity
	public void testGetSeverity()
	{
		//Setup
		PlaylistError test1 = new PlaylistError(ErrorSeverity.FATAL, 1, "#EXT FAIL", "Error");
		PlaylistError.ErrorSeverity testSeverity;
		//Test
		testSeverity = test1.getSeverity();
		//Check
		assertEquals(test1.errorSeverity, testSeverity);
	}
	
	@Test
	//Test for appropriate retrieval of getter - row number
	public void testGetRowNumber()
	{
		//Setup
		PlaylistError test1 = new PlaylistError(ErrorSeverity.FATAL, 6, "#EXT FAIL", "Error");
		int testRow;
		//Test
		testRow = test1.getRowNumber();
		//Check
		assertEquals(6, testRow);
	}
	
	@Test
	//Test for appropriate retrieval of getter - row contents
	public void testGetRowContents()
	{
		//Setup
		PlaylistError test1 = new PlaylistError(ErrorSeverity.FATAL, 6, "#EXT FAIL", "Error");
		String testContents;
		//Test
		testContents = test1.getRowContents();
		//Check
		assertEquals("#EXT FAIL", testContents);
	}
	
	@Test
	//Test for appropriate retrieval of getter - description
	public void testGetDescription()
	{
		//Setup
		PlaylistError test1 = new PlaylistError(ErrorSeverity.FATAL, 6, "#EXT FAIL", "Error");
		String testDescription;
		//Test
		testDescription  = test1.getDescription();
		//Check
		assertEquals("Error", testDescription);
	}
	
	@Test
	//Test PlaylistError constructor
	public void testPlaylistErrorConstructor() 
	{
		//Setup
		PlaylistError.ErrorSeverity severity = ErrorSeverity.FATAL;
		int row = 6;
		String contents = "EXT ERROR";
		String description = "Oopsie daisy";
		//Test
		PlaylistError testError = new PlaylistError(severity, row, contents, description);
		//Check
		assertEquals(severity, testError.getSeverity());
		assertEquals(row, testError.getRowNumber());
		assertEquals(contents, testError.getRowContents());
		assertEquals(description, testError.getDescription());
	}
}
