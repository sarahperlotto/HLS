package edu.psgv.sweng861;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Test TagOrderVisitor
public class TestTagURIVisitor 
{

	@Before
	public void setUp() throws Exception { }

	@After
	public void tearDown() throws Exception { }

	@Test
	//Test for media playlist with approp tags
	public void testMediaVisitPass() 
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("#EXT-X-TARGETDURATION:10");
		testALS.add("130130211307_1.ts");
		testALS.add("#EXTINF:10,");
		testALS.add("130130211307_2.ts");
		testALS.add("#EXTINF:10,");
		testALS.add("130130211307_3.ts");
		testALS.add("#EXTINF:10,");
		Playlist test = new MediaPlaylist(testALS, url);
		TagURIVisitor tuv = new TagURIVisitor();
		//Test
		tuv.visit(test);
		//Check
		assertEquals(true, test.validTagSequence);
	}

	@Test
	//Test for media playlist with inapprop tags
	public void testMediaVisitFail() 
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("#EXT-X-TARGETDURATION:10");
		testALS.add("130130211307_1.ts");
		testALS.add("#EXT-X-STREAM-INF:10,");
		testALS.add("130130211307_2.ts");
		testALS.add("#EXTINF:10,");
		testALS.add("130130211307_3.ts");
		testALS.add("#EXTINF:10,");
		Playlist test = new MediaPlaylist(testALS, url);
		TagURIVisitor tuv = new TagURIVisitor();
		//Test
		tuv.visit(test);
		//Check
		assertEquals(false, test.validTagSequence);
	}
	
	@Test
	//Test for master playlist with approp tags
	public void testMasterVisitPass() 
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("#EXT-X-STREAM-INF:blah");
		testALS.add("130130211307_1.ts");
		testALS.add("EXT-X-STREAM-INF:blah,blah");
		testALS.add("130130211307_2.ts");
		testALS.add("EXT-X-STREAM-INF:blah,blah,blah");
		testALS.add("130130211307_3.ts");
		Playlist test = new MasterPlaylist(testALS, url);
		TagURIVisitor tuv = new TagURIVisitor();
		//Test
		tuv.visit(test);
		//Check
		assertEquals(true, test.validTagSequence);
	}

	@Test
	//Test for master playlist with inapprop tags
	public void testMasterVisitFail() 
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("#EXT-X-STREAM-INF:blah");
		testALS.add("130130211307_1.ts");
		testALS.add("#EXTINF:10,");
		testALS.add("130130211307_2.ts");
		testALS.add("EXT-X-STREAM-INF:blah,blah,blah");
		testALS.add("130130211307_3.ts");
		Playlist test = new MasterPlaylist(testALS, url);
		TagURIVisitor tuv = new TagURIVisitor();
		//Test
		tuv.visit(test);
		//Check
		assertEquals(false, test.validTagSequence);
	}
}
