package edu.psgv.sweng861;

import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.NonStrictExpectations;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

public class TestMediaPlaylist 
{

	@Before
	public void setUp() throws Exception { }

	@After
	public void tearDown() throws Exception { }

	@Mocked LogManager mockLog;
	
	@Test
	//Test MediaPlaylist constructor
	public void testMediaConstructor() 
	{
		//Setup
		ArrayList<String> contents = new ArrayList<String>();
		contents.add("#EXTM3U");
		contents.add("#EXT-X-TARGETDURATION:10");
		contents.add("#EXTINF:10,");
		contents.add("#EXTINF:12");
		String url = "http://www.get.com/here.m3u8";
		//Test
		MediaPlaylist testPlay = new MediaPlaylist(contents, url);
		//Check
		assertEquals(testPlay.getUrl(), url);
		assertEquals(testPlay.getContents(), contents);
	}
}