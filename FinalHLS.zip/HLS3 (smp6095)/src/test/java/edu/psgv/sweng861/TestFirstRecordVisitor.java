package edu.psgv.sweng861;

import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.NonStrictExpectations;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

public class TestFirstRecordVisitor 
{
	@Before
	public void setUp() throws Exception { }

	@After
	public void tearDown() throws Exception { }
	
	@Mocked LogManager mockLog;
	
	@Test
	//Verify functionality of visit()
	public void testCheckFirstRecord()
	{
		//Setup
		FirstRecordVisitor frs = new FirstRecordVisitor();
		ArrayList<String> testPass = new ArrayList<String>();
		testPass.add("#EXTM3U");
		ArrayList<String> testFail = new ArrayList<String>();
		testFail.add("hello");
		//Check
		assertEquals(true, frs.checkFirstRecord(testPass));
		assertEquals(false, frs.checkFirstRecord(testFail));
	}
}
