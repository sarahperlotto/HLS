package edu.psgv.sweng861;

import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.NonStrictExpectations;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

public class TestMasterPlaylist 
{
	@Before
	public void setUp() throws Exception { }

	@After
	public void tearDown() throws Exception { }
	
	@Mocked LogManager mockLog;
	
	@Test
	//Test MasterPlaylist constructor
	public void testMasterConstructor() 
	{
		//Setup
		ArrayList<String> contents = new ArrayList<String>();
		contents.add("#EXTM3U");
		contents.add("#EXT-X-TARGETDURATION:10");
		contents.add("#EXTINF:10,");
		contents.add("#EXTINF:12");
		String url = "http://www.get.com/here/now.m3u8";
		//Test
		MasterPlaylist testPlay = new MasterPlaylist(contents, url);
		//Check
		assertEquals(testPlay.getUrl(), url);
		assertEquals(testPlay.getContents(), contents);
	}

	@Test
	//Test method to extract variant playlist urls
	public void testParsePlaylist() 
	{
		//Setup
		ArrayList<String> contents = new ArrayList<String>();
		contents.add("#EXTM3U");
		contents.add("#EXT-X-STREAM-INF:");
		contents.add("gear1/here.m3u8");
		contents.add("#EXT-X-STREAM-INF:");
		contents.add("gear2/here.m3u8");
		contents.add("#EXT-X-STREAM-INF:");
		contents.add("gear3/here.m3u8");
		String url = "http://www.masterplaylist.com/folder/anotherfolder/now.m3u8";
		MasterPlaylist testPlay = new MasterPlaylist(contents, url);
		ArrayList<String> actualResults = new ArrayList<String>();
		ArrayList<String> expectedResults = new ArrayList<String>();
		expectedResults.add("http://www.masterplaylist.com/folder/anotherfolder/gear1/here.m3u8");
		expectedResults.add("http://www.masterplaylist.com/folder/anotherfolder/gear2/here.m3u8");
		expectedResults.add("http://www.masterplaylist.com/folder/anotherfolder/gear3/here.m3u8");
		//Test
		actualResults = testPlay.parsePlaylist(contents);
		//Check
		assertEquals(actualResults, expectedResults);
	}
}
