package edu.psgv.sweng861;

import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.NonStrictExpectations;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Test WhitespaceVisitor 
public class TestWhitespaceVisitor 
{
	@Before
	public void setUp() throws Exception { }

	@After
	public void tearDown() throws Exception { }
	
	@Mocked LogManager mockLog;
	
	@Test
	//Verify functionality of checking method
	public void testVisit()
	{
		//Setup
		WhitespaceVisitor wsv = new WhitespaceVisitor();
		ArrayList<String> testPass = new ArrayList<String>();
		testPass.add("hello");
		testPass.add("goodbye");
		ArrayList<String> testFail = new ArrayList<String>();
		testFail.add("hello");
		testFail.add(" ");
		String url = "http://google.m3u8";
		Playlist test1 = new MediaPlaylist(testPass, url);
		Playlist test2 = new MediaPlaylist(testFail, url);
		Playlist test3 = new MasterPlaylist(testPass, url);
		Playlist test4 = new MasterPlaylist(testFail, url);
		wsv.visit(test1);
		wsv.visit(test2);
		wsv.visit(test3);
		wsv.visit(test4);
		//Check
		assertEquals(true, test1.validNoWhitespace);
		assertEquals(false, test2.validNoWhitespace);
		assertEquals(true, test3.validNoWhitespace);
		assertEquals(false, test4.validNoWhitespace);
	}
}