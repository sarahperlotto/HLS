package edu.psgv.sweng861;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Test PlaylistConstants
public class TestPlaylistConstants 
{
	@Before
	public void setUp() throws Exception { }

	@After
	public void tearDown() throws Exception { }

	@Test
	//Test values of constant variables
	public void testAll() 
	{
		assertEquals(PlaylistConstants.FIRSTRECORD, "#EXTM3U");
		assertEquals(PlaylistConstants.TARGETDURATION, "#EXT-X-TARGETDURATION");
		assertEquals(PlaylistConstants.MEDIASEGMENTDURATION, "#EXTINF");
		assertEquals(PlaylistConstants.VARIANTSTREAM, "#EXT-X-STREAM-INF");
		assertEquals(PlaylistConstants.VERSION, "#EXT-X-VERSION");
		assertEquals(PlaylistConstants.BYTERANGE, "#EXT-X-BYTERANGE");
		assertEquals(PlaylistConstants.DISCONTINUITY, "#EXT-X-DISCONTINUITY");
		assertEquals(PlaylistConstants.ENCRYPTION, "#EXT-X-KEY");
		assertEquals(PlaylistConstants.MAP, "#EXT-X-MAP");
		assertEquals(PlaylistConstants.PROGRAMDATETIME, "#EXT-X-PROGRAM-DATE-TIME");
		assertEquals(PlaylistConstants.SEQUENCE, "#EXT-X-MEDIA-SEQUENCE");
		assertEquals(PlaylistConstants.DISCONTINUITYSEQUENCE, "#EXT-X-DISCONTINUITY-SEQUENCE");
		assertEquals(PlaylistConstants.ENDLIST, "#EXT-X-ENDLIST");
		assertEquals(PlaylistConstants.TYPE, "#EXT-X-PLAYLIST-TYPE");
		assertEquals(PlaylistConstants.IFRAMES, "#EXT-X-I-FRAMES-ONLY");
		assertEquals(PlaylistConstants.MEDIAALTERNATIVE, "#EXT-X-MEDIA");
		assertEquals(PlaylistConstants.IFRAMESINF, "#EXT-X-I-FRAME-STREAM-INF");
		assertEquals(PlaylistConstants.SESSIONDATA, "#EXT-X-SESSION-DATA");
		assertEquals(PlaylistConstants.SESSIONKEY, "#EXT-X-SESSION-KEY");
		assertEquals(PlaylistConstants.INDEPENDENTSEGMENTS, "#EXT-X-INDEPENDENT-SEGMENTS");
		assertEquals(PlaylistConstants.START, "#EXT-X-START");
		assertEquals(PlaylistConstants.CACHE, "#EXT-X-ALLOW-CACHE");
	}
}
