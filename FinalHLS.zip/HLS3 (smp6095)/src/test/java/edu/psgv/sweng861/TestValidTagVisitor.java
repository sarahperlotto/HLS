package edu.psgv.sweng861;

import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.NonStrictExpectations;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Test ValidTagVisitor 
public class TestValidTagVisitor 
{

	@Before
	public void setUp() throws Exception { }

	@After
	public void tearDown() throws Exception { }

	@Test
	//Verify functionality of checking method
	public void testVisit() 
	{
		//Setup
		ValidTagVisitor vtv = new ValidTagVisitor();
		ArrayList<String> testPass = new ArrayList<String>();
		testPass.add("hello");
		testPass.add("#EXTINF");
		ArrayList<String> testFail = new ArrayList<String>();
		testFail.add("hello");
		testFail.add("#EXTBOGUS");
		String url = "http://google.m3u8";
		Playlist test1 = new MediaPlaylist(testPass, url);
		Playlist test2 = new MediaPlaylist(testFail, url);
		Playlist test3 = new MasterPlaylist(testPass, url);
		Playlist test4 = new MasterPlaylist(testFail, url);
		vtv.visit(test1);
		vtv.visit(test2);
		vtv.visit(test3);
		vtv.visit(test4);
		//Check
		assertEquals(true, test1.validTagList);
		assertEquals(false, test2.validTagList);
		assertEquals(true, test3.validTagList);
		assertEquals(false, test4.validTagList);
	}

	@Test
	//Verify tag parsing
	public void testParseTag()
	{
		//Setup
		ValidTagVisitor vtv = new ValidTagVisitor();
		String p1 ="#EXTINF";
		String p2 = "#EXTINF:blah";
		String p3 = "#EXTINF: blah";
		String p4 = "#EXTINFblah";
		String p5 = "#EXTINF\n";
		//Test
		String r1 = vtv.parseTag(p1);
		String r2 = vtv.parseTag(p2);
		String r3 = vtv.parseTag(p3);
		String r4 = vtv.parseTag(p4);
		String r5 = vtv.parseTag(p5);
		//Check
		assertEquals(r1, p1);
		assertEquals(r2, p1);
		assertEquals(r3, p1);
		assertEquals(r4, p4);
		assertEquals(r5, p5);
	}
}
