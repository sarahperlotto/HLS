package edu.psgv.sweng861;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.psgv.sweng861.PlaylistError.ErrorSeverity;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

public class TestPlaylist 
{
	@Before
	public void setUp() throws Exception { }

	@After
	public void tearDown() throws Exception { }
	
	@Test
	//Test method to truncate file path from playlist URL
	public void testTruncateUrl() 
	{
		//Setup
		ArrayList<String> contents = new ArrayList<String>();
		contents.add("#EXTM3U");
		contents.add("#EXT-X-TARGETDURATION:10");
		contents.add("#EXTINF:10,");
		contents.add("#EXTINF:12");
		String url = "http://www.get.com/here/now.m3u8";
		Playlist testPlay1 = new MasterPlaylist(contents, url);
		Playlist testPlay2 = new MediaPlaylist(contents, url);
		//Test
		String result1 = testPlay1.truncateUrl();
		String result2 = testPlay2.truncateUrl();
		//Check
		assertEquals("http://www.get.com/here/", result1);
		assertEquals("http://www.get.com/here/", result2);
	}
	
	@Test
	//Test getContents()
	public void testGetContents()
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MediaPlaylist(testALS, url);
		Playlist test2 = new MasterPlaylist(testALS, url);
		ArrayList<String> testALSresponse1 = new ArrayList<>();
		ArrayList<String> testALSresponse2 = new ArrayList<>();
		//Test
		testALSresponse1 = test1.getContents();
		testALSresponse2 = test2.getContents();
		//Check
		assertEquals(testALS, testALSresponse1);
		assertEquals(testALS, testALSresponse2);
	}
	
	@Test
	//Test getUrl()
	public void testGetUrl()
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MediaPlaylist(testALS, url);
		Playlist test2 = new MasterPlaylist(testALS, url);
		//Test
		String response1 = test1.getUrl();
		String response2 = test2.getUrl();
		//Check
		assertEquals(response1, url);
		assertEquals(response2, url);
	}
	
	@Test
	//Test getTrancatedUrl()
	public void testGetTruncatedUrl()
	{
		//Setup
		String url = "http://www.google.com/how/why.m3u8";
		String truncUrl = "http://www.google.com/how/";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MediaPlaylist(testALS, url);
		Playlist test2 = new MasterPlaylist(testALS, url);
		//Test
		String response1 = test1.getTruncatedUrl();
		String response2 = test2.getTruncatedUrl();
		//Check
		assertEquals(response1, truncUrl);
		assertEquals(response2, truncUrl);
	}
	
	@Test
	//Test getTargetDuration()
	public void testGetTargetDuration()
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MediaPlaylist(testALS, url);
		Playlist test2 = new MasterPlaylist(testALS, url);
		float test = (float) 1.1;
		test1.targetDuration = test;
		test2.targetDuration = test;
		//Test
		float response1 = test1.getTargetDuration();
		float response2 = test2.getTargetDuration();
		//Check - include allowable delta for float
		assertEquals(test, response1, 0.001);
		assertEquals(test, response2, 0.001);
	}
	
	@Test
	//Test setTargetDuration()
	public void testSetTargetDuration()
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MediaPlaylist(testALS, url);
		Playlist test2 = new MasterPlaylist(testALS, url);
		float test = (float) 1.1;
		//Test
		test1.setTargetDuration(test);
		test2.setTargetDuration(test);
		float response1 = test1.targetDuration;
		float response2 = test2.targetDuration;
		//Check - include allowable delta for float
		assertEquals(test, response1, 0.001);
		assertEquals(test, response2, 0.001);
	}
	
	@Test
	//Test set setValidFirstRecord(boolean)
	public void testSetValidFirstRecord()
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MediaPlaylist(testALS, url);
		Playlist test2 = new MasterPlaylist(testALS, url);
		boolean test = true;
		//Test
		test1.setValidFirstRecord(test);
		test2.setValidFirstRecord(test);
		boolean response1 = test1.validFirstRecord;
		boolean response2 = test2.validFirstRecord;
		//Check
		assertEquals(test, response1);
		assertEquals(test, response2);
	}
	
	@Test
	//Test set setValidFirstRecord(boolean)
	public void testSetValidDuration()
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MediaPlaylist(testALS, url);
		Playlist test2 = new MasterPlaylist(testALS, url);
		boolean test = false;
		//Test
		test1.setValidDuration(test);
		test2.setValidDuration(test);
		boolean response1 = test1.validDuration;
		boolean response2 = test2.validDuration;
		//Check
		assertEquals(test, response1);
		assertEquals(test, response2);
	}
	
	@Test
	//Test set setValidNoWhitespace(boolean)
	public void testSetValidNoWhitespace()
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MediaPlaylist(testALS, url);
		Playlist test2 = new MasterPlaylist(testALS, url);
		boolean test = true;
		//Test
		test1.setValidNoWhitespace(test);
		test2.setValidNoWhitespace(test);
		boolean response1 = test1.validNoWhitespace;
		boolean response2 = test2.validNoWhitespace;
		//Check
		assertEquals(test, response1);
		assertEquals(test, response2);
	}
	
	@Test
	//Test set setValidTagSequence(boolean)
	public void testSetValidTagSequence()
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MediaPlaylist(testALS, url);
		Playlist test2 = new MasterPlaylist(testALS, url);
		boolean test = true;
		//Test
		test1.setValidTagSequence(test);
		test2.setValidTagSequence(test);
		boolean response1 = test1.validTagSequence;
		boolean response2 = test2.validTagSequence;
		//Check
		assertEquals(test, response1);
		assertEquals(test, response2);
	}	
	
	@Test
	//Test set setValidTagList(boolean)
	public void testSetValidTagList()
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MediaPlaylist(testALS, url);
		Playlist test2 = new MasterPlaylist(testALS, url);
		boolean test = true;
		//Test
		test1.setValidTagList(test);
		test2.setValidTagList(test);
		boolean response1 = test1.validTagList;
		boolean response2 = test2.validTagList;
		//Check
		assertEquals(test, response1);
		assertEquals(test, response2);
	}	
	
	@Test
	//Test addition of new playlist error
	public void testAddPlaylistError()
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MediaPlaylist(testALS, url);
		Playlist test2 = new MasterPlaylist(testALS, url);
		PlaylistError testErr1 = new PlaylistError(ErrorSeverity.MAJOR, 1, "EXT ERROR", "Oops");
		PlaylistError testErr2 = new PlaylistError(ErrorSeverity.MINOR, 2, "EXT ERROR 2", "Darn");
		ArrayList<PlaylistError> testErrors1 = new ArrayList<>();
		testErrors1.add(testErr1);
		ArrayList<PlaylistError> testErrors2 = testErrors1;
		testErrors2.add(testErr2);
		test1.playlistErrors = testErrors1;
		test2.playlistErrors = testErrors1;
		//Test
		test1.addPlaylistError(testErr2);
		test2.addPlaylistError(testErr2);
		//Check
		assertEquals(testErrors2, test1.playlistErrors);
		assertEquals(testErrors2, test2.playlistErrors);
	}
	
	@Test
	//Test checking of media playlist error check
	public void testErrorCheckMedia()
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MediaPlaylist(testALS, url);
		Playlist test2 = new MediaPlaylist(testALS, url);
		test1.validDuration = true;
		test1.validFirstRecord = true;
		test1.validNoWhitespace = true;
		test1.validTagSequence = true;
		test2.validDuration = false;
		test2.validFirstRecord = true;
		test2.validNoWhitespace = true;
		test2.validTagSequence = true;
		//Test
		boolean result1 = test1.errorCheck();
		boolean result2 = test2.errorCheck();
		//Check
		assertEquals(result1, true);
		assertEquals(result2, false);
	}
	
	@Test
	//Test checking of master playlist error check
	public void testErrorCheckMaster()
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("Hey");
		testALS.add("What's up");
		testALS.add("Hello");
		Playlist test1 = new MasterPlaylist(testALS, url);
		Playlist test2 = new MasterPlaylist(testALS, url);
		test1.validDuration = true;
		test1.validFirstRecord = true;
		test1.validNoWhitespace = true;
		test1.validTagSequence = true;
		test2.validDuration = false;
		test2.validFirstRecord = true;
		test2.validNoWhitespace = true;
		test2.validTagSequence = true;
		//Test
		boolean result1 = test1.errorCheck();
		boolean result2 = test2.errorCheck();
		//Check
		assertEquals(result1, true);
		assertEquals(result2, false);
	}
}
