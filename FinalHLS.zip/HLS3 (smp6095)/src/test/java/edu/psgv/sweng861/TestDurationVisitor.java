package edu.psgv.sweng861;

import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.NonStrictExpectations;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//Test DurationVisitor
public class TestDurationVisitor 
{

	@Before
	public void setUp() throws Exception { }

	@After
	public void tearDown() throws Exception { }

	@Test
	//Test TargetDuration visitor on a MediaPlaylist with no errors
	public void testMediaPlaylistPass() 
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("#EXT-X-TARGETDURATION:10");
		testALS.add("130130211307_1.ts");
		testALS.add("#EXTINF:10,");
		testALS.add("130130211307_2.ts");
		testALS.add("#EXTINF:10,");
		testALS.add("130130211307_3.ts");
		testALS.add("#EXTINF:10,");
		Playlist test1 = new MediaPlaylist(testALS, url);
		DurationVisitor dvs = new DurationVisitor();
		//Test
		dvs.visit(test1);
		//Check
		assertEquals(true, test1.validDuration);
	}

	@Test
	//Test TargetDuration visitor on a MediaPlaylist with errors
	public void testMediaPlaylistFail() 
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("#EXT-X-TARGETDURATION:10");
		testALS.add("130130211307_1.ts");
		testALS.add("#EXTINF:10,");
		testALS.add("130130211307_2.ts");
		testALS.add("#EXTINF:15,");
		testALS.add("130130211307_3.ts");
		testALS.add("#EXTINF:10,");
		Playlist test2 = new MediaPlaylist(testALS, url);
		DurationVisitor dvs = new DurationVisitor();
		//Test
		dvs.visit(test2);
		//Check
		assertEquals(false, test2.validDuration);
	}
	
	@Test
	//Test TargetDuration visitor on a MasterPlaylist - does not apply, default true
	public void testMasterPlaylist() 
	{
		//Setup
		String url = "http://www.google.m3u8";
		ArrayList<String> testALS = new ArrayList<>();
		testALS.add("#EXT...");
		testALS.add("...");
		Playlist test3 = new MasterPlaylist(testALS, url);
		DurationVisitor dvs = new DurationVisitor();
		//Test
		dvs.visit(test3);
		//Check
		assertEquals(true, test3.validDuration);
	}
}
