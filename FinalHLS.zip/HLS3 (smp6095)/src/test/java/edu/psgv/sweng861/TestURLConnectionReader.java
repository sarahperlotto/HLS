package edu.psgv.sweng861;

import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.psgv.sweng861.URLConnectionReader.PlaylistType;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.NonStrictExpectations;

/*
HLS
Sarah Perlotto
SWENG 861
Fall 2016
*/

//TestURLConnectionReader
public class TestURLConnectionReader 
{

	@Before
	public void setUp() throws Exception { }

	@After
	public void tearDown() throws Exception { }

	@Test
	//Test validateInput's identification of bad entries
	public void analyzeBadInput() 
	{
		assertEquals(false, URLConnectionReader.validateInput(""));
		assertEquals(false, URLConnectionReader.validateInput("xyz"));
		assertEquals(false, URLConnectionReader.validateInput("http://xyz.com"));
		assertEquals(false, URLConnectionReader.validateInput("xyz.m3u8"));
	}
	
	@Test
	//Test validateInput's identification of good entries
	public void analyzeGoodInput() 
	{
		assertEquals(true, URLConnectionReader.validateInput("0"));
		assertEquals(true, URLConnectionReader.validateInput("http://gv8748.gv.psu.edu:8084/sweng861/simple-01/playlist.m3u8"));
		assertEquals(true, URLConnectionReader.validateInput("http://.m3u8"));
	}

	@Mocked Scanner mockScanner;
	@Mocked LogManager mockLog;
	
	@Test
	//Test scanForInput's ability to scan for good user input
	public void testScanForGoodInput()
	{
		new NonStrictExpectations()
		{{
			mockScanner.nextLine();
			result = "http://gv8748.gv.psu.edu:8084/sweng861/simple-01/playlist.m3u8";
		}};
		String theInput = URLConnectionReader.scanForInput(mockScanner);
		assertEquals("http://gv8748.gv.psu.edu:8084/sweng861/simple-01/playlist.m3u8", theInput);
	}
	
	@Test
	//Test scanForInput's ability to scan for quit user input
	public void testScanForQuitInput()
	{
		new NonStrictExpectations()
		{{
			mockScanner.nextLine();
			result = "0";
		}};
		String theInput = URLConnectionReader.scanForInput(mockScanner);
		assertEquals("0", theInput);
	}
	
	@Test
	//Test scanForInput's ability to scan for bad user input
	public void testScanForBadInput()
	{
		new NonStrictExpectations()
		{{
			mockScanner.nextLine();
			result = "xyz";
		}};
		String theInput = URLConnectionReader.scanForInput(mockScanner);
		assertEquals("xyz", theInput);
	}
	
	@Test
	//Test for appropriate scanning of user input
	public void testGetInput()
	{
		//Setup
		new MockUp<URLConnectionReader>()
		{
			int i = 0;
			int j = 0;
			String[] urls = {"xyz", "http://gv8748.gv.psu.edu:8084/sweng861/simple-01/playlist.m3u8", "0"};
			boolean[] results = {false, true, true};
			@Mock
			String scanForInput(Scanner mockScanner)
			{
				return urls[i++];
			}
			@Mock
			boolean validateInput(String url)
			{
				return results[j++];
			}
		};
		//Test
		String returnURL = URLConnectionReader.getInput(mockScanner);
		//Check results - should return first "true" String
		assertEquals("http://gv8748.gv.psu.edu:8084/sweng861/simple-01/playlist.m3u8", returnURL);
	}
	
	@Test
	//Test for appropriate printing of valid URL's contents
	public void testPrintUrlGoodContents()
	{
		//Setup
		ArrayList<String> content = new ArrayList<String>();
		content.add("#EXTM3U\n\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=232370,CODECS=\"mp4a.40.2, avc1.4d4015\"\ngear1/prog_index.m3u8\n\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=649879,CODECS=\"mp4a.40.2, avc1.4d401e\"\ngear2/prog_index.m3u8\n\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=991714,CODECS=\"mp4a.40.2, avc1.4d401e\"\ngear3/prog_index.m3u8\n\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=1927833,CODECS=\"mp4a.40.2, avc1.4d401f\"\ngear4/prog_index.m3u8\n\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=41457,CODECS=\"mp4a.40.2\"\ngear0/prog_index.m3u8\n\n");
		String expectedOutput = 
				"Playlist contents:\n\r\n#EXTM3U\n\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=232370,CODECS=\"mp4a.40.2, avc1.4d4015\"\ngear1/prog_index.m3u8\n\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=649879,CODECS=\"mp4a.40.2, avc1.4d401e\"\ngear2/prog_index.m3u8\n\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=991714,CODECS=\"mp4a.40.2, avc1.4d401e\"\ngear3/prog_index.m3u8\n\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=1927833,CODECS=\"mp4a.40.2, avc1.4d401f\"\ngear4/prog_index.m3u8\n\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=41457,CODECS=\"mp4a.40.2\"\ngear0/prog_index.m3u8\n\n\r\n";
		final ByteArrayOutputStream output = new ByteArrayOutputStream();
		System.setOut(new PrintStream(output));
		//Test
		URLConnectionReader.printUrlContents(content);
		//Check results
		final String actualOutput = output.toString();
		assertEquals(expectedOutput, actualOutput);
	}
	
	@Test
	//Test for appropriate printing of bad URL's contents
	public void testPrintUrlBadContents()
	{
		//Setup
		ArrayList<String> content = new ArrayList<String>();
		content.add("bad");
		String expectedOutput = "URL connection error / URL is not for a valid playlist\r\n";
		final ByteArrayOutputStream output = new ByteArrayOutputStream();
		System.setOut(new PrintStream(output));
		//Test
		URLConnectionReader.printUrlContents(content);
		//Check results
		final String actualOutput = output.toString();
		assertEquals(expectedOutput, actualOutput);
	}
	
	@Test
	//Evaluate master tag review - master playlist
	public void testMasterTagCheckTrue()
	{
		//Setup
		ArrayList<String> content = new ArrayList<String>();
		content.add(PlaylistConstants.VARIANTSTREAM);
		//Test
		boolean actual = URLConnectionReader.masterTagCheck(content);
		//Check
		assertEquals(true, actual);
	}
	
	@Test
	//Evaluate master tag review - non master playlist
	public void testMasterTagCheckFalse()
	{
		//Setup
		ArrayList<String> content = new ArrayList<String>();
		content.add("Unicorns exist!");
		//Test
		boolean actual = URLConnectionReader.masterTagCheck(content);
		//Check
		assertEquals(false, actual);
	}
	
	@Test
	//Evaluate media tag checks - media playlist
	public void testMediaTagChecksTrue()
	{
		//Setup
		ArrayList<String> content = new ArrayList<String>();
		content.add(PlaylistConstants.TARGETDURATION);
		content.add(PlaylistConstants.MEDIASEGMENTDURATION);
		//Test
		boolean actual1 = URLConnectionReader.mediaTagCheck1(content);
		boolean actual2 = URLConnectionReader.mediaTagCheck2(content);
		//Check
		assertEquals(true, actual1);
		assertEquals(true, actual2);
	}
	
	@Test
	//Evaluate media tag checks - media playlist
	public void testMediaTagChecksFalse()
	{
		//Setup
		ArrayList<String> content = new ArrayList<String>();
		content.add("I'm king of the universe!");
		//Test
		boolean actual1 = URLConnectionReader.mediaTagCheck1(content);
		boolean actual2 = URLConnectionReader.mediaTagCheck2(content);
		//Check
		assertEquals(false, actual1);
		assertEquals(false, actual2);
	}
	
	@Test
	//Evaluate playlist type check - master playlist
	public void testPlaylistTypeMaster()
	{
		//Setup
		ArrayList<String> content = new ArrayList<String>();
		content.add(PlaylistConstants.VARIANTSTREAM);
		//Test
		PlaylistType type = URLConnectionReader.determinePlaylistType(content);
		//Check
		assertEquals(type, PlaylistType.MASTER);
	}
	
	@Test
	//Evaluate playlist type check - master playlist
	public void testPlaylistTypeMedia()
	{
		//Setup
		ArrayList<String> content = new ArrayList<String>();
		content.add(PlaylistConstants.TARGETDURATION);
		content.add(PlaylistConstants.MEDIASEGMENTDURATION);
		//Test
		PlaylistType type = URLConnectionReader.determinePlaylistType(content);
		//Check
		assertEquals(type, PlaylistType.MEDIA);
	}
	
	@Test
	//Evaluate playlist type check - playlist with master and media tags, invalid
	public void testPlaylistTypeInvalid()
	{
		//Setup
		ArrayList<String> content = new ArrayList<String>();
		content.add(PlaylistConstants.TARGETDURATION);
		content.add(PlaylistConstants.MEDIASEGMENTDURATION);
		content.add(PlaylistConstants.VARIANTSTREAM);
		//Test
		PlaylistType type = URLConnectionReader.determinePlaylistType(content);
		//Check
		assertEquals(type, PlaylistType.INVALID);
	}
}